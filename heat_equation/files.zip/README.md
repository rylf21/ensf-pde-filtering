# Heat Equation — EnSF State Estimation

This folder contains the FEniCSx solver and Ensemble Score Filter (EnSF)
implementation for state estimation of a parametric heat equation, corresponding
to Chapter 3 of the dissertation:

> López Fajardo, R.Y. *Model–Data Integration in Complex Dynamical Systems:
> Applications in Materials Synthesis.* Florida State University, 2026.

---

## Problem

Diffusion on $\Omega = (-1,1)^2$ with spatially varying Gaussian permeability:

$$\frac{\partial u}{\partial t} - \nabla \cdot (K(x,y;\theta)\, \nabla u) = f(x,y)$$

with split Dirichlet boundary conditions ($u=1$ on $\Gamma_0$, $u=0$ on $\Gamma_1$)
and nonlinear arctan observation model $Y_t = \arctan(X_t) + \varepsilon_t$.

---

## Files

| File | Description |
|------|-------------|
| `solver.py` | `HeatEquationProblem` class and `create_mesh` function |
| `ensf.py` | `reverse_SDE` sampler and `make_score_likelihood_arctan` |
| `01_run_experiment.ipynb` | Generates truth, runs EnSF for 100%/25%/5% observations, saves HDF5 |
| `02_visualize.ipynb` | Loads HDF5 results and produces thesis figures |

---

## Repo structure

```
heat_equation/
├── solver.py
├── ensf.py
├── 01_run_experiment.ipynb
├── 02_visualize.ipynb
data/                   # HDF5 outputs (generated, not tracked by git)
figures/                # PDF/PNG figures (generated, not tracked by git)
```

---

## Dependencies

- [FEniCSx (DOLFINx)](https://fenicsproject.org/) — finite element framework
- [RBniCSx](https://github.com/RBniCS/RBniCSx) — symbolic parameter handling
- [gmsh](https://gmsh.info/) — mesh generation
- numpy, h5py, matplotlib, tqdm, scikit-image (for inpainting, optional)

Installation via conda is strongly recommended for FEniCSx:

```bash
conda create -n fenicsx-env -c conda-forge fenics-dolfinx mpich
conda activate fenicsx-env
pip install rbnicsx gmsh h5py tqdm scikit-image
```

---

## Attribution

The FEniCSx solver structure (backward Euler time discretization, variational
form, `LinearProblem` usage) is adapted from:

> Dokken, J.S. *FEniCSx Tutorial*, Chapter 2 — The Heat Equation.
> https://jsdokken.com/dolfinx-tutorial/chapter2/heat_equation.html
> Licensed under CC BY 4.0.

Modifications from the tutorial:
- Spatially varying Gaussian permeability field $K(x,y;\theta)$
- Parametric interface via `rbnicsx.backends.SymbolicParameters`
- Split inhomogeneous Dirichlet boundary conditions
- Class-based solver interface for use as a forecast operator inside an
  ensemble filtering loop

The EnSF algorithm is based on:

> Bao, F., Ye, Z., Zhou, Z., & Chen, Y. (2022). *An Ensemble Score Filter
> for Tracking High-Dimensional Nonlinear Dynamical Systems.*
> https://arxiv.org/abs/2206.03824
